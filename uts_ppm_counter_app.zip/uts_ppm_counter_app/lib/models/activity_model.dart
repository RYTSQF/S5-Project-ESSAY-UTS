class ActivityModel {
  final String id;
  final String name;
  final int count;

  const ActivityModel({
    required this.id,
    required this.name,
    this.count = 0,
  });

  ActivityModel copyWith({
    String? id,
    String? name,
    int? count,
  }) {
    return ActivityModel(
      id: id ?? this.id,
      name: name ?? this.name,
      count: count ?? this.count,
    );
  }
}