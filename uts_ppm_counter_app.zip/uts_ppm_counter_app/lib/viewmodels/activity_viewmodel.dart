import 'package:flutter/foundation.dart';
import '../models/activity_model.dart';
import '../repositories/activity_repositories.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository;

  ActivityViewModel(this._repository);

  List<ActivityModel> get activities => _repository.getAllActivities();

  ActivityModel? findById(String id) => _repository.getById(id);

  bool addActivity(String name) {
    if (name.trim().isEmpty) return false;
    _repository.addActivity(name);
    notifyListeners();
    return true;
  }

  bool updateActivityName(String id, String newName) {
    if (newName.trim().isEmpty) return false;
    _repository.updateActivityName(id, newName);
    notifyListeners();
    return true;
  }

  bool incrementCount(String id) {
    final current = _repository.getById(id);
    if (current == null) return false;

    _repository.updateCount(id, current.count + 1);
    notifyListeners();
    return true;
  }

  bool decrementCount(String id) {
    final current = _repository.getById(id);
    if (current == null || current.count <= 0) return false;

    _repository.updateCount(id, current.count - 1);
    notifyListeners();
    return true;
  }

  bool resetCount(String id) {
    final current = _repository.getById(id);
    if (current == null) return false;

    _repository.updateCount(id, 0);
    notifyListeners();
    return true;
  }

  bool deleteActivity(String id) {
    final exists = _repository.getById(id) != null;
    if (!exists) return false;

    _repository.deleteActivity(id);
    notifyListeners();
    return true;
  }
}