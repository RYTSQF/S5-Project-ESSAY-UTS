import 'package:flutter/material.dart';
import '../viewmodels/activity_viewmodel.dart';

class ActivityDetailView extends StatelessWidget {
  final ActivityViewModel viewModel;
  final String activityId;

  const ActivityDetailView({
    super.key,
    required this.viewModel,
    required this.activityId,
  });

  void _showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _onIncrement(BuildContext context) {
    final changed = viewModel.incrementCount(activityId);
    if (changed && context.mounted) {
      final updated = viewModel.findById(activityId);
      _showSnackBar(
        context,
        'Nilai counter ditambah menjadi ${updated?.count ?? 0}.',
      );
    }
  }

  void _onDecrement(BuildContext context) {
    final changed = viewModel.decrementCount(activityId);
    if (changed && context.mounted) {
      final updated = viewModel.findById(activityId);
      _showSnackBar(
        context,
        'Nilai counter dikurangi menjadi ${updated?.count ?? 0}.',
      );
    } else if (context.mounted) {
      _showSnackBar(
        context,
        'Nilai counter sudah 0 dan tidak bisa kurang dari 0.',
      );
    }
  }

  Future<void> _onResetPressed(BuildContext context) async {
    final activity = viewModel.findById(activityId);
    if (activity == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Konfirmasi Reset'),
        content: Text(
          'Apakah kamu yakin ingin mereset nilai counter "${activity.name}" menjadi 0?',
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      final didReset = viewModel.resetCount(activityId);
      if (didReset) {
        _showSnackBar(context, 'Nilai counter direset menjadi 0.');
      }
    }
  }

  Future<void> _onDeletePressed(BuildContext context) async {
    final activity = viewModel.findById(activityId);
    if (activity == null) return;

    final activityName = activity.name;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Konfirmasi Hapus'),
        content: Text(
          'Apakah kamu yakin ingin menghapus aktivitas "$activityName"?',
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      final deleted = viewModel.deleteActivity(activityId);
      if (deleted) {
        Navigator.pop(context, activityName);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: viewModel,
      builder: (context, _) {
        final activity = viewModel.findById(activityId);

        if (activity == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Detail Aktivitas')),
            body: const Center(child: Text('Aktivitas tidak ditemukan.')),
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text('Detail Aktivitas'),
          ),
          body: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.outlineVariant,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        activity.name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        '${activity.count}',
                        style: TextStyle(
                          fontSize: 56,
                          fontWeight: FontWeight.w800,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text('Total Hitungan'),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () => _onDecrement(context),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 16,
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.remove),
                          SizedBox(width: 6),
                          Text('Kurang (-)'),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    ElevatedButton(
                      onPressed: () => _onIncrement(context),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 16,
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add),
                          SizedBox(width: 6),
                          Text('Tambah (+)'),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => _onResetPressed(context),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reset'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
                const Spacer(),
                ElevatedButton.icon(
                  onPressed: () => _onDeletePressed(context),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Hapus Aktivitas'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.errorContainer,
                    foregroundColor:
                        Theme.of(context).colorScheme.onErrorContainer,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}