import 'package:flutter/material.dart';
import '../viewmodels/activity_viewmodel.dart';

class ActivityFormView extends StatefulWidget {
  final ActivityViewModel viewModel;
  final String? activityId;

  const ActivityFormView({
    super.key,
    required this.viewModel,
    this.activityId,
  });

  @override
  State<ActivityFormView> createState() => _ActivityFormViewState();
}

class _ActivityFormViewState extends State<ActivityFormView> {
  late final TextEditingController _nameController;
  String? _errorText;

  bool get _isEditing => widget.activityId != null;

  @override
  void initState() {
    super.initState();
    final existing = widget.activityId != null
        ? widget.viewModel.findById(widget.activityId!)
        : null;
    _nameController = TextEditingController(text: existing?.name ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _handleSave() {
    final cleanName = _nameController.text.trim();
    if (cleanName.isEmpty) {
      setState(() {
        _errorText = 'Nama aktivitas tidak boleh kosong.';
      });
      return;
    }

    final success = _isEditing
        ? widget.viewModel.updateActivityName(widget.activityId!, cleanName)
        : widget.viewModel.addActivity(cleanName);

    if (success && mounted) {
      Navigator.pop(context, cleanName);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Aktivitas' : 'Tambah Aktivitas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _isEditing
                  ? 'Perbarui nama aktivitas yang dipilih:'
                  : 'Masukkan nama aktivitas harian yang ingin dicatat:',
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _nameController,
              textCapitalization: TextCapitalization.sentences,
              autofocus: true,
              decoration: InputDecoration(
                labelText: 'Nama Aktivitas',
                hintText: 'Contoh: Push Up, Baca Jurnal, Lari Sore',
                border: const OutlineInputBorder(),
                errorText: _errorText,
              ),
              onChanged: (_) {
                if (_errorText != null) {
                  setState(() => _errorText = null);
                }
              },
              onSubmitted: (_) => _handleSave(),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _handleSave,
              icon: const Icon(Icons.check),
              label: const Text('Simpan'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}