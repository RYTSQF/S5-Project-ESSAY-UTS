import 'package:flutter/material.dart';
import 'data/activity_data.dart';
import 'repositories/activity_repositories.dart';
import 'viewmodels/activity_viewmodel.dart';
import 'views/activity_home_view.dart';

void main() {
  final activityData = ActivityData();
  final activityRepository = ActivityRepository(activityData);
  final activityViewModel = ActivityViewModel(activityRepository);

  runApp(ActivityCounterApp(viewModel: activityViewModel));
}

class ActivityCounterApp extends StatelessWidget {
  final ActivityViewModel viewModel;

  const ActivityCounterApp({super.key, required this.viewModel});

  @override
  Widget build(BuildContext context) {
    // Palet Warna Khas Discord (Dark + Blurple)
    const discordBg = Color(0xFF313338); // Background utama
    const discordSurface = Color(0xFF2B2D31); // Card & AppBar
    const discordDarkest = Color(0xFF1E1F22); // Input & Container dalam
    const discordBlurple = Color(0xFF5865F2); // Aksen Biru Discord
    const discordTextPrimary = Color(0xFFF2F3F5); // Teks putih lembut
    const discordTextSecondary = Color(0xFFB5BAC1); // Teks abu-abu terang
    const discordRed = Color(0xFFDA373C); // Merah untuk tombol Hapus

    return MaterialApp(
      title: 'Activity Counter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: discordBg,
        colorScheme: const ColorScheme.dark(
          primary: discordBlurple,
          onPrimary: Colors.white,
          primaryContainer: discordBlurple,
          onPrimaryContainer: Colors.white,
          surface: discordSurface,
          onSurface: discordTextPrimary,
          surfaceContainerLow: discordSurface,
          onSurfaceVariant: discordTextSecondary,
          outlineVariant: Color(0xFF3F4147),
          errorContainer: discordRed,
          onErrorContainer: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: discordDarkest,
          foregroundColor: discordTextPrimary,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: discordSurface,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: Color(0xFF3F4147), width: 1),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: discordBlurple,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: discordBlurple,
          foregroundColor: Colors.white,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: discordDarkest,
          labelStyle: const TextStyle(color: discordTextSecondary),
          hintStyle: const TextStyle(color: Color(0xFF80848E)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: discordBlurple, width: 2),
          ),
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: discordSurface,
          titleTextStyle: const TextStyle(
            color: discordTextPrimary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          contentTextStyle: const TextStyle(
            color: discordTextSecondary,
            fontSize: 15,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: discordDarkest,
          contentTextStyle: const TextStyle(color: discordTextPrimary),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      home: HomeView(viewModel: viewModel),
    );
  }
}