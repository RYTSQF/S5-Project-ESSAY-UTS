import '../models/activity_model.dart';

class ActivityData {
  final List<ActivityModel> activities = [
    const ActivityModel(
      id: 'act-1',
      name: 'Baca Buku',
      count: 2,
    ),
    const ActivityModel(
      id: 'act-2',
      name: 'Olahraga Pagi',
      count: 1,
    ),
    const ActivityModel(
      id: 'act-3',
      name: 'Kerjakan Tugas Kuliah',
      count: 0,
    ),
  ];
}