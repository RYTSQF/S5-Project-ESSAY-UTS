import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _dataSource;

  ActivityRepository(this._dataSource);

  List<ActivityModel> getAllActivities() {
    return List<ActivityModel>.unmodifiable(_dataSource.activities);
  }

  ActivityModel? getById(String id) {
    try {
      return _dataSource.activities.firstWhere((item) => item.id == id);
    } catch (_) {
      return null;
    }
  }

  void addActivity(String name) {
    final trimmedName = name.trim();
    final newActivity = ActivityModel(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: trimmedName,
      count: 0,
    );
    _dataSource.activities.add(newActivity);
  }

  void updateActivityName(String id, String newName) {
    final index = _dataSource.activities.indexWhere((item) => item.id == id);
    if (index == -1) return;

    final current = _dataSource.activities[index];
    _dataSource.activities[index] = current.copyWith(name: newName.trim());
  }

  void updateCount(String id, int newCount) {
    final index = _dataSource.activities.indexWhere((item) => item.id == id);
    if (index == -1) return;

    final safeCount = newCount < 0 ? 0 : newCount;
    final current = _dataSource.activities[index];
    _dataSource.activities[index] = current.copyWith(count: safeCount);
  }

  void deleteActivity(String id) {
    _dataSource.activities.removeWhere((item) => item.id == id);
  }
}