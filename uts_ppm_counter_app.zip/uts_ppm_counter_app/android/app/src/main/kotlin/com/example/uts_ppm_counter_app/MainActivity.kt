package com.example.uts_ppm_counter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
